// Distance Between Two Points Calculator

// √ (x2 - x1)^2 + (y2 - y1)^2

// Event Listener
document.getElementById("convert-btn").addEventListener("click", calculate);

// Even Function
function calculate() {

    // Get inputs
    let a = document.getElementById("inputEl1").value;
    let b = document.getElementById("inputEl2").value;
    let x = document.getElementById("inputEl3").value;
    let y = document.getElementById("inputEl4").value;
    
    document.getElementById("results").innerHTML = calcDistance(a, b, x, y);
} 

function calcDistance(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1));
}